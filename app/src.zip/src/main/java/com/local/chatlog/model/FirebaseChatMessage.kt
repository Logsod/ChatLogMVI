package com.local.chatlog.model


data class FirebaseChatMessage(val fromUid: String, val message: String, val timestamp: Long) {
    constructor() : this("", "", 0)
}