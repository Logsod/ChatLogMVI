package com.local.chatlog.di

import com.local.chatlog.interfaces.Repository
import com.local.chatlog.repository.RepositoryImp
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module()
class Module {
    @Provides
    @Singleton
    fun provideRepository(): Repository {
        return RepositoryImp()
    }
}