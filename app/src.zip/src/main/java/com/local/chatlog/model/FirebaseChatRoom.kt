package com.local.chatlog.model

data class FirebaseChatRoom(
    val roomId: String,
    val uid1: String,
    val uid2: String,
    val createdOn: String
) {
    constructor() : this("", "", "", "")
}
