package com.local.chatlog.interfaces

import com.local.chatlog.model.ChatUser
import kotlinx.coroutines.ExperimentalCoroutinesApi

interface ChatLogViewModel {
    fun getCurrentUid(): String
    fun handleIntent()

    @ExperimentalCoroutinesApi
    fun receiveMessages(roomId: String)
}