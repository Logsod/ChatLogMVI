package com.local.chatlog.model

data class FirebaseChatUser(val uid : String, val userName: String, val userImageUri: String) {
    constructor() : this( "","", "")
}