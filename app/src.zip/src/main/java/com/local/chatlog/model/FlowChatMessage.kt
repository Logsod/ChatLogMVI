package com.local.chatlog.model

import java.lang.Exception

sealed class FlowChatMessage() {
    class FlowChatNewMessage(val key : String, val chatMessage: ChatMessage) : FlowChatMessage()
    class FlowChatRemoveMessage(val key : String, val chatMessage: ChatMessage) : FlowChatMessage()
    class FlowChatError(e : Exception) : FlowChatMessage()
}