package com.local.chatlog.repository

import com.local.chatlog.model.ChatRoom
import com.local.chatlog.model.ChatUser

sealed class UserListData {
    class Added(val chatUser: ChatUser) : UserListData()
    class Remove(val chatUser: ChatUser) : UserListData()
    class Fail(val e: Exception) : UserListData()
}

sealed class UserMessageData {
    object Success : UserMessageData()
    class Fail(val e: Exception) : UserMessageData()
}

sealed class UserAuthData {
    //object LoginDataReceivedSuccess : UserAuthData()
    object Success : UserAuthData()
    object ImageLoadSuccess : UserAuthData()
    object ImageLoadFail : UserAuthData()
    class Fail(val e: Exception) : UserAuthData()
}

sealed class UserRoomData {
    class Success(val chatRoom: ChatRoom) : UserRoomData()
    class Fail(val e: Exception) : UserRoomData()
}
