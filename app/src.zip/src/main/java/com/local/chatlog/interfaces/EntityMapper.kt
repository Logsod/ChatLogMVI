package com.local.chatlog.interfaces

interface EntityMapper<E, D> {
    fun fromEntity(entity: E): D
    fun fromData(data D): E
}